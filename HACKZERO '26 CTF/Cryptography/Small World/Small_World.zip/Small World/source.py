import random

class LCG:
    A = 1664525
    C = 1013904223
    M = 2**32

    def __init__(self, seed):
        self.state = seed

    def next(self):
        self.state = (self.A * self.state + self.C) % self.M
        return self.state

def encrypt_flag(seed, flag_text):
    lcg = LCG(seed)
    leak = lcg.next()
    
    encrypted_bytes = []
    for char in flag_text:
        key_byte = lcg.next() % 256
        cipher_byte = ord(char) ^ key_byte
        encrypted_bytes.append(cipher_byte)
    
    return bytes(encrypted_bytes).hex()

#seed = random.randint(0, 1000)
#print(encrypt_flag(seed, "hackzero{...}"))
